/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'cs', {
	label: 'Styl',
	panelTitle: 'Formátovací styly',
	panelTitle1: 'Blokové styly',
	panelTitle2: 'Řádkové styly',
	panelTitle3: 'Objektové styly'
} );
