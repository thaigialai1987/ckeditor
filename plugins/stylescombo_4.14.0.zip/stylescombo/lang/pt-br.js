/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'pt-br', {
	label: 'Estilo',
	panelTitle: 'Estilos de Formatação',
	panelTitle1: 'Estilos de bloco',
	panelTitle2: 'Estilos de texto corrido',
	panelTitle3: 'Estilos de objeto'
} );
